"""
No hay una solucion unica, hay varias maneras de hacerlo, lo unico que debe de coincidir es el resultado esperado, la metodologia que se use depende de como piense cada quien.
En los ejercicios se combina lo que hemos visto en estas dos clases y algunos tienen cosas que no hemos visto, para que aprendan a usar la mejor herramienta dle programador que es
GOOGLEAR...

Hint: Lo que no sepan hacer, pongan en google (ingles): Como fusionar dos diccionarios por ejemplo.
"""

# Ejercicios Python

# Ejercicios Diccionarios


# 1. Escriba un script de Python para agregar una clave a un diccionario.

# 2. Escriba un script de Python para concatenar los siguientes diccionarios para crear uno nuevo.
# Diccionario de muestra
# dic1={1:10, 2:20}
# dic2={3:30, 4:40}
# dic3={5:50,6:60}


# 3. Escriba un script de Python para verificar si una clave dada ya existe en un diccionario

d = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}

# 4. Escriba un programa de Python para iterar sobre diccionarios usando bucles for

d = {'x': 10, 'y': 20, 'z': 30} 

# 5. Escriba un script de Python para generar e imprimir un diccionario que contenga un número (entre 1 y n) en la forma (x, x*x).

# Diccionario de muestra (n = 5):
# Salida esperada: {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}

# 6. Escriba un script de Python para fusionar dos diccionarios de Python
d1 = {'a': 100, 'b': 200}
d2 = {'x': 300, 'y': 200}

# 7. Escriba un programa de Python para iterar sobre diccionarios usando bucles for.

# 8. Escriba un programa en Python para sumar todos los elementos de un diccionario.

my_dict = {'data1':100,'data2':-54,'data3':247}

# 9. Escriba un programa en Python para multiplicar todos los elementos de un diccionario
my_dict = {'data1':100,'data2':-54,'data3':247}

# 10. Escriba un programa Python para eliminar una clave de un diccionario.
myDict = {'a':1,'b':2,'c':3,'d':4}




# Ejercicio Listas

# 1. Escriba un programa en Python para sumar todos los elementos de una lista.


# 2. Escriba un programa en Python para multiplicar todos los elementos de una lista.

# 3. Escriba un programa en Python para obtener el número más grande de una lista

# 4. Escriba un programa en Python para obtener el número más pequeno de una lista

# 5. Escriba un programa de Python para contar el número de cadenas de texto donde la longitud de la cadena es 2 o más y el primer y último carácter son los mismos de una 
# lista de cadenas dada.
# Lista de muestras: ['abc', 'xyz', 'aba', '1221']
# Resultado esperado: 2

# 6. Escriba un programa de Python para obtener una lista, ordenada en orden creciente por el último elemento de cada tupla de una lista dada de tuplas no vacías. 
# Lista de muestra: [(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]
# Resultado esperado: [(2, 1), (1, 2), (2, 3), (4, 4), (2, 5)] 

# 7. Escriba un programa de Python para eliminar duplicados de una lista.

a = [10,20,30,20,10,50,60,40,80,50,40]

# 8. Escriba un programa de Python para verificar que una lista esté vacía o no.


