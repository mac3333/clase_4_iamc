# sdasfasfasfasgasgadgagasggsgagasgassga

# creo una varible de precio de punta bid
# bid = 100

"""
esto es un comentario
de bloques
varias lineas
"""

precio_ggal_ayer = 100
# paso un segundo
precio_ggal_despues_minuto = 120.06
precio_byma = "No tiene precio"
byma_data_precio = None

# operaciones matematicas con variables
precio_ggal_hoy = 120

retorno_galicia = ((precio_ggal_hoy / precio_ggal_ayer) - 1) * 100
# print(retorno_galicia)
# print('El retorno de galicia es de: {}'.format(retorno_galicia))
# imprimir tipo de varibale
# print(type(precio_ggal_hoy))

# tipos de datos BASICOS
dato_int = 200  # esto es un numero entero
dato_float = 19.966873628763785535235325  # eto es un numero float (decimal)
datos_caden_tezto = "esto es una cadena de texto"  # tambien se usan comillas simples ' '

# HIT ----> NO se puede hacer operaciones matematicas entre int, float y str

#######################################################################################################################

# estructuras de datos basicas I
esto_es_una_lista = [22, 11, 250.25, "ask"]  # pueden tener int, float, str y otras estructuras

# particularidades de lista
    # 1. Son ordenadas
    # 2. Las listas entran por indice: Primera posi 0, segunda posi es 1 ....
    # 3. Se consultan de atras en adelante tambien... -n
    # 4. se recorren... se hace un loop

# si quiero el primer valor de la lista
primer_valor_lista = esto_es_una_lista[0]
tercer_valor_lista = esto_es_una_lista[2]


esto_es_una_diccionario = {"valor_prrueba": 22, "valor_prrueba_2": 32333}  # pueden tener int, float, str y otras estructuras
esto_es_una_diccionario["precio_ask"] = 12  # aca crean una nueva key
# print(esto_es_una_diccionario["valor_prrueba"])

esto_es_una_tuplas = (250, 35.25)  # pueden tener int, float, str y otras estructuras
# particularidades de tuplas
    # 1. NO se pueden cambiar los valores, son inmutables
    # 2. Entras por indice.... Que se usan igual que las listas





